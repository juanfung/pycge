# **pycge**: a Python package for CGE modeling #

The goal of this project is to write and solve a Computable
General Equilibrium (CGE) model in Python, using the package
[pyomo](www.pyomo.org) as the back end.
