# -*- coding: utf-8 -*-
"""
Created on Thu Jul 27 14:13:56 2017

@author: cmb11
"""

from distutils.core import setup

setup(
        name='PyCGE',
        version='0.1dev',
        packages=['pycge']
        )